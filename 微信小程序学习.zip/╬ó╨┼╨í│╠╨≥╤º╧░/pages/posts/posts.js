// pages/posts/posts.js
// onLoad onShow onReady

Page({

  /**
   * 页面的初始数据
   */

  //数据绑定
  data: {
    //date: "Nov 25 2018"
    //posts_key:[{},{}]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //用来调试 console.log("页面onLoad");
    //从服务器获取到的json格式数据
    //把数据传到data下
    var post_content = [
      //第一篇
      {
        date: "Nov 25 2018",
        title: "健康扶贫政策的建议",
        img: {
          post_img: "/images/post/crab.png",
          author_img: "/images/avatar/2.png"
        },
        a: 1,
        b: 2,
        c: 3,
        img_condition: true,
        content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
        view_num: "76",
        collect_num: "96"
        },
      //第二篇
      {
        date: "Nov 25 2017",
        title: "健康扶贫政策的建议",
        img: {
          post_img: "/images/post/bl.png",
          author_img: "/images/avatar/2.png"
        },
        a: 1,
        b: 2,
        c: 3,
        img_condition: true,
        content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
        view_num: "76",
        collect_num: "96"
        }
    ]
    //把数据传到data下 
    //this.setData(post_content);
    this.setData(
      {posts_key: post_content}
    );
  },
  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})