// pages/posts/post-detail/post-detail.js

//postData是一个对象，他有2个属性postList、__proto__
var postsData = require("../../../data/posts-data.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var postId = options.id; /*从posts.js接收postid*/
    //console.log(postId);
    var postData = postsData.postList[postId];
    //console.log(postData);
    
    //数据绑定，目前采用了异步方法，可能this.setData没执行完，onLoad就结束了。
    //被删除的是同步方法this.data,同步方法执行完成，onLoad才结束。
    this.setData(
      { posts_key: postData }
    );
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})