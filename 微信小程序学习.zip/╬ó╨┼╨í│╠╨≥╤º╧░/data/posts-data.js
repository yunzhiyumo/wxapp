var post_content = [
  //第一篇
  {
    date: "Nov 25 2018",
    title: "健康扶贫政策的建议",
    img: {
      post_img: "/images/post/crab.png",
      author_img: "/images/avatar/2.png"
    },
    img_condition: true,
    content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
    view_num: "76",
    collect_num: "96",
    postId:0
  },
  //第二篇
  {
    date: "Nov 25 2017",
    title: "健康扶贫政策的建议",
    img: {
      post_img: "/images/post/bl.png",
      author_img: "/images/avatar/2.png"
    },
    img_condition: true,
    content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
    view_num: "76",
    collect_num: "96",
    postId: 1
  },
  //3
  {
    date: "Nov 25 2017",
    title: "健康扶贫政策的建议",
    img: {
      post_img: "/images/post/bl.png",
      author_img: "/images/avatar/2.png"
    },
    img_condition: true,
    content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
    view_num: "76",
    collect_num: "96",
    postId: 2
  },
  //4
  {
    date: "Nov 25 2017",
    title: "健康扶贫政策的建议",
    img: {
      post_img: "/images/post/bl.png",
      author_img: "/images/avatar/2.png"
    },
    img_condition: true,
    content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
    view_num: "76",
    collect_num: "96",
    postId: 3
  },
  //5
  {
    date: "Nov 25 2017",
    title: "健康扶贫政策的建议",
    img: {
      post_img: "/images/post/bl.png",
      author_img: "/images/avatar/2.png"
    },
    img_condition: true,
    content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
    view_num: "76",
    collect_num: "96",
    postId: 4
  },
  //6
  {
    date: "Nov 25 2017",
    title: "健康扶贫政策的建议",
    img: {
      post_img: "/images/post/bl.png",
      author_img: "/images/avatar/2.png"
    },
    img_condition: true,
    content: "在今年的全国两会上，全国政协委员、北京大学第一医院丁洁教授提交了《关于将“乡村儿童大病医保”模型纳入健康扶贫政策的建议》的政协议案。",
    view_num: "76",
    collect_num: "96",
    postId: 5
  }

]


//定义出口
module.exports = {
  postList: post_content
}