<?php
/**
 * Created by PhpStorm.
 * User: pm123
 * Date: 2018/2/25
 * Time: 0:04
 */

namespace app\api\model;


use think\Exception;

class BannerModel
{
    public static function getBannerByID($id){
/*        try{
            1/0;
        }
        catch (Exception $e){

            throw $e;
        }*/
    return null;
    }
}