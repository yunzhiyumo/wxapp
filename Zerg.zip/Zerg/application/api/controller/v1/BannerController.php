<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/2/24
 * Time: 12:06
 */

namespace app\api\controller\v1;

use app\api\model\BannerModel;
use app\api\validate\IDMustBePositiveInt;
use app\lib\exception\BannerMissException;
use think\Exception;

class BannerController
{
    //获取指定id的banner信息
    //@id banner id
    //@url /banner/:id
    //@GET
    public function getBanner($id){
        (new IDMustBePositiveInt()) -> goCheck();
        $banner = BannerModel::getBannerByID($id);
        if (!$banner){
            throw new BannerMissException();
        }
        return $banner;
    }
}