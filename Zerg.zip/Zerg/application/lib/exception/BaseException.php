<?php
/**
 * Created by PhpStorm.
 * User: pm123
 * Date: 2018/2/25
 * Time: 23:09
 */

namespace app\lib\exception;

// 由用户行为导致的异常
use think\Exception;

class BaseException extends Exception
{
    // HTTP 状态码 200，400
    public $code = 400;

    // 错误具体信息
    public $msg = '参数错误';

    // 自定义的错误码
    public $errorCode = 10000;
}